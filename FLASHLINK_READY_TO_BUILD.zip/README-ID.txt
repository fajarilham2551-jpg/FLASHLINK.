FLASHLINK v1.0 — SOURCE PROJECT + AUTO BUILD

Ini source project Android, bukan APK yang sudah dikompilasi.

CARA PALING MUDAH MEMBUAT APK TANPA ANDROID STUDIO:
1. Buat akun GitHub jika belum punya.
2. Buat repository baru bernama FLASHLINK.
3. Upload seluruh isi ZIP ini ke repository (termasuk folder .github).
4. Buka tab Actions di repository.
5. Pilih workflow "Build FLASHLINK APK" lalu tekan Run workflow.
   Workflow juga berjalan otomatis setelah push ke branch main.
6. Tunggu sampai selesai, buka hasil run, lalu unduh artifact
   bernama FLASHLINK-debug-apk.
7. Ekstrak artifact ZIP untuk mendapatkan app-debug.apk.

CARA PAKAI:
1. Instal APK yang sama di kedua HP Android.
2. Pair kedua HP melalui Pengaturan > Bluetooth.
3. HP yang lampunya akan dikendalikan: buka app > MODE TARGET.
4. HP pengendali: buka app > MODE REMOTE > pilih HP target.
5. Tekan SENTER ON atau SENTER OFF.

CATATAN:
- Android 6.0+ (API 23+) secara teknis didukung; perangkat wajib memiliki Bluetooth.
- Kedua HP harus berada dalam jangkauan Bluetooth.
- Aplikasi meminta izin Bluetooth dan Kamera untuk mengendalikan flash.
- Jika koneksi terputus, flash pada HP target dimatikan.
- Tidak semua perangkat Android mendukung kontrol flash saat kondisi tertentu.
- Gunakan hanya pada perangkat milik sendiri atau dengan izin pemiliknya.

Build memakai Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, dan Android SDK 35.
