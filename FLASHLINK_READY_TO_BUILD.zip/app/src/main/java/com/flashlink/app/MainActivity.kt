package com.flashlink.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val uuid: UUID = UUID.fromString("7a1f2b30-6d91-4f15-9b1a-7e5c2a9d1001")
    private val reqCode = 42
    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var server: BluetoothServerSocket? = null
    private var output: OutputStream? = null
    private var role = ""
    private var torchOn = false
    private var cameraId: String? = null
    private lateinit var status: TextView
    private lateinit var body: LinearLayout
    private lateinit var manager: CameraManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BluetoothAdapter.getDefaultAdapter()
        manager = getSystemService(CAMERA_SERVICE) as CameraManager
        cameraId = try {
            manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(
                    android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE
                ) == true
            }
        } catch (_: Exception) { null }
        buildHome()
        ensurePermissions()
    }

    private fun ensurePermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), reqCode)
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(7, 17, 31))
        }
        val title = TextView(this).apply {
            text = "FLASHLINK"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "KONTROL SENTER VIA BLUETOOTH"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Pilih peran untuk mulai"
            textSize = 15f
            setTextColor(Color.rgb(100, 200, 255))
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 22)
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(body)
        setContentView(root)
        addButton(body, "📡  MODE REMOTE", true) { chooseRemote() }
        addButton(body, "🔦  MODE TARGET (SENTER)", false) { startTarget() }
        val note = TextView(this).apply {
            text = "Pastikan kedua HP sudah dipasangkan (pair) lewat Pengaturan Bluetooth."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(note)
    }

    private fun addButton(parent: LinearLayout, label: String, primary: Boolean, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(if (primary) Color.rgb(0, 125, 220) else Color.rgb(35, 55, 78))
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 62)
        lp.setMargins(0, 9, 0, 9)
        parent.addView(b, lp)
    }

    private fun setStatus(message: String) {
        runOnUiThread { status.text = message }
    }

    private fun readyBluetooth(): Boolean {
        if (adapter == null) {
            setStatus("HP ini tidak mendukung Bluetooth.")
            return false
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ensurePermissions()
            setStatus("Izinkan akses Bluetooth, lalu tekan tombol lagi.")
            return false
        }
        if (adapter?.isEnabled != true) {
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 7)
            return false
        }
        return true
    }

    private fun chooseRemote() {
        if (!readyBluetooth()) return
        role = "REMOTE"
        val bonded = try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (_: SecurityException) { emptyList() }
        if (bonded.isEmpty()) {
            setStatus("Belum ada perangkat yang dipasangkan. Pair kedua HP di Pengaturan Bluetooth.")
            return
        }
        val names = bonded.map { "${it.name ?: "Perangkat"}  (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih HP TARGET")
            .setItems(names) { _, which -> connectRemote(bonded[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun connectRemote(device: BluetoothDevice) {
        setStatus("Menghubungkan ke ${device.name ?: "HP target"}…")
        thread {
            try {
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                socket = s
                output = s.outputStream
                setStatus("TERHUBUNG • ${device.name ?: "TARGET"}")
                runOnUiThread { showRemoteControls() }
            } catch (e: Exception) {
                setStatus("Gagal terhubung. Pastikan mode TARGET aktif dan kedua HP sudah pair.")
            }
        }
    }

    private fun showRemoteControls() {
        body.removeAllViews()
        addButton(body, "🔦  SENTER ON", true) { sendCommand("ON") }
        addButton(body, "🌑  SENTER OFF", false) { sendCommand("OFF") }
        addButton(body, "PUTUSKAN KONEKSI", false) {
            sendCommand("OFF")
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            output = null
            buildHome()
        }
    }

    private fun sendCommand(command: String) {
        thread {
            try {
                output?.write("$command\n".toByteArray())
                output?.flush()
                setStatus(if (command == "ON") "Perintah SENTER ON terkirim" else "Perintah SENTER OFF terkirim")
            } catch (_: Exception) {
                setStatus("Koneksi terputus. Sambungkan ulang.")
            }
        }
    }

    private fun startTarget() {
        if (!readyBluetooth()) return
        if (cameraId == null) {
            setStatus("Flash kamera tidak ditemukan di HP ini.")
            return
        }
        role = "TARGET"
        body.removeAllViews()
        addButton(body, "HENTIKAN MODE TARGET", false) {
            try { server?.close() } catch (_: Exception) {}
            setTorch(false)
            buildHome()
        }
        setStatus("MODE TARGET AKTIF • Menunggu remote…")
        thread {
            try {
                server = adapter!!.listenUsingRfcommWithServiceRecord("FLASHLINK", uuid)
                val incoming = server!!.accept()
                socket = incoming
                setStatus("REMOTE TERHUBUNG • Siap menerima perintah")
                val reader = BufferedReader(InputStreamReader(incoming.inputStream))
                while (true) {
                    val command = reader.readLine() ?: break
                    when (command.trim().uppercase()) {
                        "ON" -> setTorch(true)
                        "OFF" -> setTorch(false)
                    }
                }
            } catch (_: Exception) {
                setStatus("Mode target berhenti atau koneksi terputus.")
            } finally {
                setTorch(false)
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            if (cameraId != null) {
                manager.setTorchMode(cameraId!!, on)
                torchOn = on
                setStatus(if (on) "SENTER MENYALA" else "SENTER MATI")
            }
        } catch (_: Exception) {
            setStatus("Tidak bisa mengakses flash. Tutup aplikasi kamera lain.")
        }
    }

    override fun onDestroy() {
        setTorch(false)
        try { socket?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
